'use strict'

import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)


const _2a406545 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\login.vue') : require('E:\\new\\wms\\pages\\login.vue')

const _0632f550 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home.vue') : require('E:\\new\\wms\\pages\\wms\\home.vue')

const _5f716540 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\check.vue') : require('E:\\new\\wms\\pages\\wms\\home\\check.vue')

const _324f24ca = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\warehouse.vue') : require('E:\\new\\wms\\pages\\wms\\home\\warehouse.vue')

const _2f2dab43 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\transfer.vue') : require('E:\\new\\wms\\pages\\wms\\home\\transfer.vue')

const _cde046c2 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\putInStorage.vue') : require('E:\\new\\wms\\pages\\wms\\home\\putInStorage.vue')

const _4babdf30 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\preStorage.vue') : require('E:\\new\\wms\\pages\\wms\\home\\preStorage.vue')

const _ae804cb6 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\outStorage.vue') : require('E:\\new\\wms\\pages\\wms\\home\\outStorage.vue')

const _2ff2ebb9 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\enterprise.vue') : require('E:\\new\\wms\\pages\\wms\\home\\enterprise.vue')

const _772ed106 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\preTransfer.vue') : require('E:\\new\\wms\\pages\\wms\\home\\preTransfer.vue')

const _1c62f8a9 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\detail.vue') : require('E:\\new\\wms\\pages\\wms\\home\\detail.vue')

const _5ddaf8c2 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\moveStorage.vue') : require('E:\\new\\wms\\pages\\wms\\home\\moveStorage.vue')

const _15e2cab0 = process.BROWSER_BUILD ? () => System.import('E:\\new\\wms\\pages\\wms\\home\\preOutStorage.vue') : require('E:\\new\\wms\\pages\\wms\\home\\preOutStorage.vue')

const _921497a2 = process.BROWSER_BUILD ? () => System.import('~/pages/login.vue') : require('~/pages/login.vue')



const scrollBehavior = (to, from, savedPosition) => {
  // savedPosition is only available for popstate navigations.
  if (savedPosition) {
    return savedPosition
  } else {
    let position = {}
    // if no children detected
    if (to.matched.length < 2) {
      // scroll to the top of the page
      position = { x: 0, y: 0 }
    }
    else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
      // if one of the children has scrollToTop option set to true
      position = { x: 0, y: 0 }
    }
    // if link has anchor,  scroll to anchor by returning the selector
    if (to.hash) {
      position = { selector: to.hash }
    }
    return position
  }
}


export default new Router({
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  scrollBehavior,
  routes: [
		{
			path: "/login",
			component: _2a406545,
			name: "login"
		},
		{
			path: "/wms/home",
			component: _0632f550,
			name: "wms-home",
			children: [
				{
					path: "check",
					component: _5f716540,
					name: "wms-home-check"
				},
				{
					path: "warehouse",
					component: _324f24ca,
					name: "wms-home-warehouse"
				},
				{
					path: "transfer",
					component: _2f2dab43,
					name: "wms-home-transfer"
				},
				{
					path: "putInStorage",
					component: _cde046c2,
					name: "wms-home-putInStorage"
				},
				{
					path: "preStorage",
					component: _4babdf30,
					name: "wms-home-preStorage"
				},
				{
					path: "outStorage",
					component: _ae804cb6,
					name: "wms-home-outStorage"
				},
				{
					path: "enterprise",
					component: _2ff2ebb9,
					name: "wms-home-enterprise"
				},
				{
					path: "preTransfer",
					component: _772ed106,
					name: "wms-home-preTransfer"
				},
				{
					path: "detail",
					component: _1c62f8a9,
					name: "wms-home-detail"
				},
				{
					path: "moveStorage",
					component: _5ddaf8c2,
					name: "wms-home-moveStorage"
				},
				{
					path: "preOutStorage",
					component: _15e2cab0,
					name: "wms-home-preOutStorage"
				}
			]
		},
		{
			path: "/",
			component: _921497a2,
			name: "test"
		},
		{
			path: "/wms",
			component: _921497a2,
			name: "test1"
		},
		{
			path: "/wms/",
			component: _921497a2,
			name: "test2"
		}
  ]
})
